import {
  cadastrarEpi,
  listarTodosEpis,
  buscarEpi,
  adicionarQuantidadeEstoque,
  retirarQuantidadeEstoque,
  atualizarEpi,
  excluirEpi
} from './epiController.js';


console.log('\n=== CADASTRO DE EPIs ===');

cadastrarEpi(1, 'Capacete de Segurança', '12345', 10);
cadastrarEpi(2, 'Luvas de Proteção', '23456', 20);
cadastrarEpi(3, 'Óculos de Proteção', '34567', 15);


console.log('\n=== LISTA DE EPIs ===');
listarTodosEpis();


console.log('\n=== BUSCAR EPI ===');
console.log(buscarEpi(1));


console.log('\n=== ADICIONAR QUANTIDADE ===');
console.log('Operação realizada:', adicionarQuantidadeEstoque(0, 5));


console.log('\n=== RETIRAR QUANTIDADE ===');
console.log('Operação realizada:', retirarQuantidadeEstoque(1, 3));


console.log('\n=== TESTE DE RETIRADA INVÁLIDA ===');
console.log('Operação realizada:', retirarQuantidadeEstoque(0, 100));


console.log('\n=== ATUALIZAR EPI ===');
console.log(
  'Operação realizada:',
  atualizarEpi(2, 3, 'Óculos de Proteção Ampliados', '34567', 25)
);


console.log('\n=== EXCLUIR EPI ===');
console.log('Operação realizada:', excluirEpi(1));


console.log('\n=== LISTA FINAL DE EPIs ===');
listarTodosEpis();