import { Epi } from './epi.js';

import {
  cadastrarEpi as cadastrarEpiRepository,
  listarEpis,
  buscarEpiPorIndice,
  atualizarEpi as atualizarEpiRepository,
  excluirEpi as excluirEpiRepository
} from './epiRepository.js';

export function cadastrarEpi(codigo, nome, ca, quantidade) {
  const epi = new Epi(codigo, nome, ca, quantidade);

  cadastrarEpiRepository(epi);

  console.log('EPI cadastrado com sucesso!');
}

export function listarTodosEpis() {
  const epis = listarEpis();

  if (epis.length === 0) {
    console.log('Nenhum EPI cadastrado.');
    return;
  }

  for (let i = 0; i < epis.length; i++) {
    console.log(`Índice: ${i}`);
    console.log(`Código: ${epis[i].codigo}`);
    console.log(`Nome: ${epis[i].nome}`);
    console.log(`CA: ${epis[i].ca}`);
    console.log(`Quantidade: ${epis[i].quantidade}`);
    console.log('-------------------------');
  }
}

export function buscarEpi(indice) {
  const epi = buscarEpiPorIndice(indice);

  if (!epi) {
    console.log('EPI não encontrado no índice informado.');
    return;
  }

  return epi;
}

export function atualizarEpi(indice, codigo, nome, ca, quantidade) {
  const epiExistente = buscarEpiPorIndice(indice);

  if (!epiExistente) {
    console.log('EPI não encontrado no índice informado.');
    return false;
  }

  const epiAtualizado = new Epi(codigo, nome, ca, quantidade);

  return atualizarEpiRepository(indice, epiAtualizado);
}

export function excluirEpi(indice) {
  const epi = buscarEpiPorIndice(indice);

  if (!epi) {
    console.log('EPI não encontrado no índice informado.');
    return false;
  }

  return excluirEpiRepository(indice);
}

export function adicionarQuantidadeEstoque(indice, valor) {
  const epi = buscarEpiPorIndice(indice);

  if (!epi) {
    console.log('EPI não encontrado no índice informado.');
    return false;
  }

  const resultado = epi.adicionarQuantidade(valor);

  if (!resultado) {
    console.log('Não foi possível adicionar a quantidade informada.');
  }

  return resultado;
}

export function retirarQuantidadeEstoque(indice, valor) {
  const epi = buscarEpiPorIndice(indice);

  if (!epi) {
    console.log('EPI não encontrado no índice informado.');
    return false;
  }

  const resultado = epi.retirarQuantidade(valor);

  if (!resultado) {
    console.log('Não foi possível retirar a quantidade informada.');
  }

  return resultado;
}